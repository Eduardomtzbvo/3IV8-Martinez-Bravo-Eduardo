import java.util.*;
public class Pricosto{

    public void ejecutaPri () {
        Scanner leer = new Scanner(System.in);
        System.out.println("Inserta tu numero telefonico");
        String numero = leer.nextLine();

        System.out.println("Inserte el plan que quiera usar");
        System.out.println("1. locales nacionales");
        System.out.println("2. locales internacionales");
        System.out.println("3. celulares");
        int opcion = leer.nextInt();

        Costo costo = new Costo(numero);
        if (opcion==1){
            System.out.println("Dime cuantos minutos lo vas a usar");
            int minutos = leer.nextInt();
            costo.restarMinutosNac(minutos);
        } else if (opcion==2){
            System.out.println("Dime cuantos minutos lo vas a usar");
            int minutos = leer.nextInt();
            costo.restarMinutosInter(minutos);
        } else if (opcion == 3){
            System.out.println("Dime cuantos minutos lo vas a usar");
            int minutos = leer.nextInt();
            costo.restarMinutosCel(minutos);
        }

        System.out.println("El saldo de " + numero + " es" );
        System.out.println("El monto restante de tus minutos nacionales es:" + costo.calcularCostoNacional());

        System.out.println("El monto restante de tus minutos internacionales es: " + costo.calcularCostoInternacional());

        System.out.println("El monto restante de tus minutos de celular es: " + costo.calcularCostoCelular());
        
    }
}