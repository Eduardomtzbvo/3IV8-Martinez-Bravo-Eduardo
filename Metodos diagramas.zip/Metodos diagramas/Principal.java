import java.util.*;
public class Principal{

   public static void main(String[] args) {
       
   
    Scanner leer = new Scanner(System.in);
    System.out.println("Elige el programa que quieras correr");
    System.out.println("1. Edad");
    System.out.println("2. Area y Perimetro");
    System.out.println("3. Costo");
    System.out.println("4. Salir");
    int valor = leer.nextInt();

    Datos datos = new Datos();
    Prinf prinf = new Prinf();
    Pricosto pricosto = new Pricosto();

    while(valor !=4){
        if (valor == 4){
            System.out.println("Gracias por participar");
        }else if (valor==1){
        datos.ejecutaDatos();
    }else if(valor==2){
        prinf.ejecutaPrinf();
    }else if(valor==3){
        pricosto.ejecutaPri();
    }
    System.out.println("Elige el programa que quieras correr");
System.out.println("1. Edad");
System.out.println("2. Area y Perimetro");
System.out.println("3. Costo");
System.out.println("4. Salir");
valor = leer.nextInt();
}

   }
}