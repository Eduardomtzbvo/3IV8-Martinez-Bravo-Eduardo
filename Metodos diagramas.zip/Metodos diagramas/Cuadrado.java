public class Cuadrado{
    
    private double base = 0.0;
    private double acua = 0.0;
    private double pcua = 0.0;

        public Cuadrado(double base) {
            this.base = base;
        }

        public double calcularAreaCuadrado(){
            double acua = 0.0;
            acua = base * base;
            return acua;
        }

        public double calcularPerimetroCuadrado(){
            double pcua = 0.0;
            pcua = base + base + base + base;
            return pcua;
        }
}