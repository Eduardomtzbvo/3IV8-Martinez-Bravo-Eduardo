public class Triangulo{
    
    private double base = 0.0;
    private double l2 = 0.0;
    private double l3 = 0.0;
    private double altura = 0.0;
    private double atri = 0.0;
    private double ptri = 0.0;

        public Triangulo(double base,double l2, double l3, double altura) {
            this.base = base;
            this.l2 = l2;
            this.l3 = l3;
            this.altura = altura;
        }

        public double calcularAreaTriangulo(){
            double atri = 0.0;
            atri = (base * altura)/2;
            return atri;
        }

        public double calcularPerimetroTriangulo(){
            double ptri = 0.0;
            ptri = base + l2 + l3;
            return ptri;
        }
}