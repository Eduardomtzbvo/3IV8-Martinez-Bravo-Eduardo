
import java.util.*;
public class Persona{

        
        private int ano = 0;
        private int mes = 0;
        private int dia = 0;
        private int edad = 0;
        private String nombre = "";

        public Persona(int ano, int mes, int dia, String nombre) {
            this.ano=ano;
            this.mes=mes;
            this.dia=dia;
            this.edad=edad;
            this.nombre=nombre;            
        }
        
        public int calcularEdad(){
            int edad = 0;
            Calendar calendario = Calendar.getInstance();
            int anoes = calendario.get(Calendar.YEAR);
            edad = anoes - ano;
            return edad;
        }
            
}