import java.util.*;

public class Rectangulo{
    
    private double base = 0.0;
    private double altura = 0.0;
    private double arec = 0.0;
    private double prec = 0.0;

        public Rectangulo(double base, double altura) {
            this.base = base;
            this.altura = altura;
        }

        public double calcularAreaRectangulo(){
            double arec = 0.0;
            arec = base * altura;
            return arec;
        }

        public double calcularPerimetroRectangulo(){
            double prec = 0.0;
            prec = base + base + altura + altura;
            return prec;
        }
}