public class Costo{
    
    private float cosNacional = 0.5f;
    private float cosInter = 0.6f;
    private float cosCel = 0.2f;
    private float credito = 0.0f;
    private float creditoNa = 0.0f;
    private float creditoIn = 0.0f;
    private float creditoCel = 0.0f;
    private String numero = "";
    private int opcion = 0; 
    private int minNa = 100;
    private int minIn = 100;
    private int minCel = 100;

    public Costo( String numero){
        this.numero = numero;
    }

    public void restarMinutosNac(int minutosNa){

        minNa = minNa - minutosNa;
    }

    public void restarMinutosInter(int minutosInter){

        minIn = minIn - minutosInter;
    }

    public void restarMinutosCel(int minutosCel){

        minCel = minCel - minutosCel;
    }

    public float calcularCostoNacional(){
    return(cosNacional * minNa);
   }

   public float calcularCostoInternacional(){
       return(cosInter * minIn);
   }

   public float calcularCostoCelular(){
       return(cosCel * minCel);
   }
}