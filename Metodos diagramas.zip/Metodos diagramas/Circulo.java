import java.util.*;
import java.math.*;

public class Circulo{
    
    private double radio = 0.0;
    private double diametro = 0.0;
    private double acir = 0.0;
    private double pcir = 0.0;

        public Circulo(double radio, double diametro) {
            this.radio = radio;
            this.diametro = diametro;
        }

        public double calcularAreaCirculo(){
            double acir = 0.0;
            acir = Math.PI * (radio * radio);
            return acir;
        }

        public double calcularPerimetroCirculo(){
            double pcir = 0.0;
            pcir = diametro * Math.PI;
            return pcir;
        }
}