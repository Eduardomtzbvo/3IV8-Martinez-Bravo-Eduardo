import java.util.*;
public class Datos{

    public void ejecutaDatos() {
            
        Scanner leer = new Scanner(System.in);
        System.out.println("Por favor, inserte el ano en el que nacio");
        int anoac = leer.nextInt();
        System.out.println("Por favor, inserte el mes en que nacio");
        int mesnac = leer.nextInt();
        System.out.println("Inserte el dia en que nacio");
        int dianac = leer.nextInt();
        leer.nextLine();
        System.out.println("Inserte su nombre");
        String nombre = leer.nextLine();

        Persona persona = new Persona(anoac, mesnac, dianac, nombre);
        int edad = persona.calcularEdad();
        System.out.println("La edad de "+ nombre + " es o va a cumplir este ano es " + edad);

    }

}