import java.util.*;
public class Prinf{
    public void ejecutaPrinf() {
        Scanner leer = new Scanner(System.in);
        System.out.println("Escriba el numero de la figura el cual quiera saber su Area y Perimetro");
        System.out.println("1 Circulo");
        System.out.println("2 Rectangulo");
        System.out.println("3 Cuadrado");
        System.out.println("4 Triangulo");
        int valor = leer.nextInt();

            if(valor==1){
                System.out.println("Escriba el valor del radio");
                double radio = leer.nextFloat();
                System.out.println("Escriba el valor del diametro");
                double diametro = leer.nextFloat();
                Circulo circulo = new Circulo(radio, diametro);
                double area = circulo.calcularAreaCirculo();
                System.out.println("El area del Circulo es " + area);

                double perimetro = circulo.calcularPerimetroCirculo();
                System.out.println("El perimetro del Circulo es " + perimetro);

            }else if(valor==2){
                System.out.println("Escriba el valor de la base");
                double base = leer.nextFloat();
                System.out.println("Escriba el valor de la altura");
                double altura = leer.nextFloat();
                Rectangulo rectangulo = new Rectangulo(base, altura);
                double area = rectangulo.calcularAreaRectangulo();
                System.out.println("El area del Rectangulo es " + area);

                double perimetro = rectangulo.calcularPerimetroRectangulo();
                System.out.println("El perimetro de el Rectangulo es " + perimetro);

            }else if(valor==3){
                System.out.println("Escriba el valor de uno de sus lados");
                double base = leer.nextFloat();
                Cuadrado cuadrado = new Cuadrado(base);
                double area = cuadrado.calcularAreaCuadrado();
                System.out.println("El area del Cuadrado es " + area);

                double perimetro = cuadrado.calcularPerimetroCuadrado();
                System.out.println("El perimetro de el Cuadrado es " + perimetro);

            }else if(valor==4){
                System.out.println("Dame el valor del primer lado");
                double base = leer.nextFloat();
                System.out.println("Dame el valor del segundo lado");
                double l2 = leer.nextFloat();
                System.out.println("Dame el valor del tercer lado");
                double l3 = leer.nextFloat();
                System.out.println("Dame el valor de la altura");
                double altura = leer.nextFloat();
                Triangulo triangulo = new Triangulo(base, l2, l3, altura);
                double area = triangulo.calcularAreaTriangulo();
                System.out.println("El area del triangulo es " + area);

                double perimetro = triangulo.calcularAreaTriangulo();
                System.out.println("El perimetro del tirangulo es " + perimetro);
            }
        }
    }


