import java.io.IOException;

public class TareaGato {

	public static void main(String[] args) throws IOException {
		Gato miGato = new Gato();
		boolean gameOver = false;
		char player1 = 'X';
		miGato.crearTablero();
		while (!gameOver) {
			miGato.jugar(player1);
			miGato.imprimirGato();
			if (miGato.isGanador(player1)) {
				System.out.println("***********************************************************");
				System.out.println("******************Felicidades jugador: " + player1 + " ****************");
				System.out.println("*****************Has ganado el juego************************");
				gameOver = true;
			} else {
				if (!miGato.isLugaresDisponibles()) {
					System.out.println("*****************No hay ganador en esta partida!!!*******************");
					gameOver = true;
				} else if (player1 == 'X')
					player1 = 'O';
				else
					player1 = 'X';
			}
		}

	}
}
