import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Gato {
	
	
	
	public void imprimirPosiciones() {
		int pos = 1;
		System.out.println("********************************************************************");
		System.out.println("****************Selecciona una posicion en el gato***************** ");
		System.out.println("***********Las casillas marcadas con X u O ya estan ocupadas**********");
		System.out.println("********************************************************************");

		for (int i = 0; i < gato.length; i++) {
			for (int j = 0; j < gato.length; j++) {
				if (gato[i][j] == 'X' || gato[i][j] == 'O')
					System.out.print(" " + gato[i][j]);
				else
					System.out.print(" " + pos);
				pos++;
			}
			System.out.println();
		}
	}

	public boolean casillaNoOcupada(int posicion) {
		switch (posicion) {
		case 1:
			return gato[0][0] != ' ';
		case 2:
			return gato[0][1] != ' ';
		case 3:
			return gato[0][2] != ' ';
		case 4:
			return gato[1][0] != ' ';
		case 5:
			return gato[1][1] != ' ';
		case 6:
			return gato[1][2] != ' ';
		case 7:
			return gato[2][0] != ' ';
		case 8:
			return gato[2][1] != ' ';
		case 9:
			return gato[2][2] != ' ';
		default:
			return false;
		}
	}

	public  void jugar(char jugada) throws IOException {
		boolean salir = false;
		String entrada;
		BufferedReader bufer = new BufferedReader(new InputStreamReader(System.in));
		int posicion;
		do {
			imprimirPosiciones();
			System.out.println("*Escribe el numero donde deseas tirar: ");
			entrada = bufer.readLine();
			posicion = Integer.parseInt(entrada);
			if (casillaNoOcupada(posicion)) {
				switch (posicion) {
				case 1:
					gato[0][0] = jugada;
					break;
				case 2:
					gato[0][1] = jugada;
					break;
				case 3:
					gato[0][2] = jugada;
					break;
				case 4:
					gato[1][0] = jugada;
					break;
				case 5:
					gato[1][1] = jugada;
					break;
				case 6:
					gato[1][2] = jugada;
					break;
				case 7:
					gato[2][0] = jugada;
					break;
				case 8:
					gato[2][1] = jugada;
					break;
				case 9:
					gato[2][2] = jugada;
					break;
				}
				salir = true;
			} else
				System.out.println("Juagada no válida, vuelva a tirar");
		} while (!salir);
	}

	public  void imprimirGato() {
		System.out.println("El gato hasta el momento: ");
		for (char[] gato1 : gato) {
			for (int j = 0; j < gato.length; j++) {
				System.out.print("    " + gato1[j]);
			}
			System.out.println();
		}

	}

	public  boolean ganaPorRenglon(char caracter) {

		for (char[] gato1 : gato) {
			if (gato1[0] == caracter && gato1[1] == caracter && gato1[2] == caracter) {
				return true;
			}
		}
		return false;
	}

	public  boolean ganaPorColumna(char caracter) {

		for (int i = 0; i < gato.length; i++) {
			if (gato[0][i] == caracter && gato[1][i] == caracter && gato[2][i] == caracter)
				return true;
		}
		return false;
	}

	public  boolean ganaPorDiagonales(char caracter) {
		if (gato[0][0] == caracter && gato[1][1] == caracter && gato[2][2] == caracter)
			return true;
		if (gato[0][2] == caracter && gato[1][1] == caracter && gato[2][0] == caracter)
			return true;

		return false;
	}

	public  boolean isGanador(char caracter) {
		if (ganaPorRenglon(caracter))
			return true;
		if (ganaPorColumna(caracter))
			return true;
		if (ganaPorDiagonales(caracter))
			return true;
		return false;
	}

	public  boolean isLugaresDisponibles() {
		for (char[] gato1 : gato) {
			for (int j = 0; j < gato.length; j++) {
				if (gato1[j] == '-') {
					return true;
				}
			}
		}
		return false;
	}

	public  void crearTablero() {
		for (int i = 0; i < gato.length; i++)
			for (int j = 0; j < gato.length; j++)
				gato[i][j] = '-';
	}

	private char[][] gato = new char[3][3];

	
}
