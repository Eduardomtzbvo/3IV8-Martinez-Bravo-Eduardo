package mx.com.examples;

public class ProCalificaciones {


public float proCalificaciones(float[] numeros) {
	float promedio=0.0f;
	float suma=0.0f;
	int length = 0;
	
	for (int i = 0; i < numeros.length; i++) {
		float f = numeros[i];
		if(f!=0.0f) {
			length++;
		}
		suma= suma +  f;
		
	}
	
	promedio= suma /length;
	return promedio;
}


}
