package mx.com.examples;

import java.util.Scanner;
import java.util.StringTokenizer;

public class MatrizPrincipal {
	public void execute() {
		int suma=0;
		MatrizPrincipal mat = new MatrizPrincipal();
		Matriz matrizS = new Matriz();
		int[][] matrizA = new int[3][3];
		int[][] matrizB = new int[3][3];
		
		int[] arA1 = new int[3];
		int[] arA2 = new int[3];
		int[] arA3 = new int[3];
		arA1 = mat.leerLinea();
		arA2 = mat.leerLinea();
		arA3 = mat.leerLinea();
		int[] arB1 = new int[3];
		int[] arB2 = new int[3];
		int[] arB3 = new int[3];
		arB1 = mat.leerLinea();
		arB2 = mat.leerLinea();
		arB3 = mat.leerLinea();

		matrizA = inicializarArreglo(arA1, arA2, arA3);
		matrizB = inicializarArreglo(arB1, arB2, arB3);
		suma=matrizS.sumarArreglo(matrizA)+ matrizS.sumarArreglo(matrizB);
		System.out.println("La suma de la matriz A con la Matriz B es:" + suma);

	}

	private static int[][] inicializarArreglo(int[] ar1, int[] ar2, int[] ar3) {
		int[][] bidimensional = new int[3][3];
		for (int i = 0; i < bidimensional.length; i++) {
			int[] js = bidimensional[i];
			for (int j = 0; j < js.length; j++) {
				if (i == 0) {
					bidimensional[i][j] = ar1[j];
				}else if(i==1) {
					bidimensional[i][j] = ar2[j];
				}else {
					bidimensional[i][j] = ar3[j];
				}
			}

		}

		return bidimensional;
	}

	public int[] leerLinea() {
		Scanner leer = new Scanner(System.in);
		String texto = "";
		String token = "";
		int numero = 0;
		int[] arreglo = new int[3];
		int i = 0;

		System.out.println("Excribe 3 numeros, separados cada uno por un espacio :");
		texto = leer.nextLine();
		StringTokenizer iterar = new StringTokenizer(texto);
		while (iterar.hasMoreElements()) {
			token = iterar.nextToken();
			numero = new Integer(token);
			arreglo[i] = numero;
		i++;
		}
		return arreglo;
	}
}
