package mx.com.examples;

import java.util.Scanner;
import java.util.StringTokenizer;

public class CalProCalif {

	public void calPromedio() {
		Scanner leer = new Scanner(System.in);
		String texto = "";
		float[] calificaciones = new float[10];
		String token = "";
		float numero = 0.0f;
		int i = 0;
		ProCalificaciones proCalificaciones = new ProCalificaciones();
		float numeroMayor = 0.0f;
		float numeroMenor = 10.0f;
		float promedio = 0.0f;
		int length=0;

		System.out.println("Escriba 10 calificaciones, cada uno separados por un espacio para saber su promedio" + ": ");
		texto = leer.nextLine();
		StringTokenizer iterar = new StringTokenizer(texto);
		while (iterar.hasMoreElements()) {
			token = iterar.nextToken();
			numero = new Float(token);

			if (numero > 0) {
				calificaciones[i] = numero;
			}
			i++;
			if (numeroMayor < numero) {
				numeroMayor = numero;
			}
			if (numeroMenor > numero) {
				numeroMenor = numero;
			}
		}
		promedio=proCalificaciones.proCalificaciones(calificaciones);
		System.out.println("Las calificaciones de los alumnos son :" + texto);
		System.out.println("El promedio de las calificaciones es :" + promedio);
		System.out.println("La calificacion mayor es :" + numeroMayor);
		System.out.println("La calificacion menor es :" + numeroMenor);
		System.out.println("Las calificaciones que estan arriba del promedio son :" );
		
		for(int i2 = 0; i2<calificaciones.length; i2++) {
			float calificacion = calificaciones[i2];
			if(calificacion>promedio) {
				System.out.println(calificacion);
			}
		}
	}
}
