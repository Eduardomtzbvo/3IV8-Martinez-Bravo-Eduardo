package mx.com.examples;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Promedio {
	
	public void mostrarPromedio() {
		Scanner leer=new Scanner(System.in);
		String texto="";
		float[] positivos = new float[10];
		float[] negativos=new float[10];
		String token ="";
		float numero = 0.0f;
		int i = 0;
		CalcularPromedio calcularPromedio = new CalcularPromedio();
		
		System.out.println("Escriba 10 numeros, cada uno separados por un espacio: ");
		texto=leer.nextLine();
		StringTokenizer iterar = new StringTokenizer(texto);
		while(iterar.hasMoreElements()) {
			token=iterar.nextToken();
			numero=new Float(token);
			
			if(numero>0) {
				positivos[i]=numero;
			}else {
				negativos[i]=numero;
			}
				i++;
		}
		System.out.println("El promedio de los numeros positivos es :" + calcularPromedio.calcularPromedio(positivos));
		System.out.println("El promedio de los numeros negativos es :" + calcularPromedio.calcularPromedio(negativos));
	}

}
