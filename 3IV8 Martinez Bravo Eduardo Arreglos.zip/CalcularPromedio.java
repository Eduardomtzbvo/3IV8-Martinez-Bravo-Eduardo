package mx.com.examples;

public class CalcularPromedio {
	
	
//	public static void main(String[] args) {
//		
//		float[] numeros= new float[] {10.0f,20.0f,30.0f};
//		
//		new CalcularPromedio().calcularPromedio(numeros);
//	}
	
	
	public float calcularPromedio(float[] numeros) {
		float promedio=0.0f;
		float suma=0.0f;
		int length = 0;
		
		for (int i = 0; i < numeros.length; i++) {
			float f = numeros[i];
			if(f!=0.0f) {
				length++;
			}
			suma= suma +  f;
			
		}
		
		promedio= suma /length;
		return promedio;
	}
	

}
