package mx.com.examples;

import java.util.Scanner;
import java.util.StringTokenizer;

public class CalPromedioPar {
	public void mostrarPromedio() {
		Scanner leer = new Scanner(System.in);
		String texto = "";
		float[]pares = new float[10];
		String token = "";
		float numero = 0.0f;
		int i = 0;
		PromedioPar promedioPar = new PromedioPar();
				
		System.out.println("Inserte 10 numeros separados cada uno por espacios");
		texto=leer.nextLine();
		StringTokenizer iterar = new StringTokenizer(texto);
		while(iterar.hasMoreElements()) {
			token = iterar.nextToken();
			numero = new Float(token);
			
			if(numero%2==0) {
				pares[i]=numero;
			}
			i++;
		}
		System.out.println("El promedio de los numeros pares es :" + promedioPar.promedioPar(pares));
}
}
