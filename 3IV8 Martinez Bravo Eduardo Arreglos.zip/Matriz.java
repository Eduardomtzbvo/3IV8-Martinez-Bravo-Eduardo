package mx.com.examples;

public class Matriz {
	

	public int sumarArreglo(int[][] bidimensional) {
		int suma = 0;
		for (int i = 0; i < bidimensional.length; i++) {
			int[] js = bidimensional[i];
			for (int j = 0; j < js.length; j++) {
				suma= suma +bidimensional[i][j];
			}
		}
		return suma;
	}

}
