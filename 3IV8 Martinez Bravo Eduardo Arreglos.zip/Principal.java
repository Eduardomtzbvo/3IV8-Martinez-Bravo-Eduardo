package mx.com.examples;

import java.util.Scanner;

public class Principal {
	
	
	public static void main(String[] args) {
		int texto = 0;
		texto = new Principal().leerLinea();
		while (texto != 5) {

			if (texto == 3) {
				new CalProCalif().calPromedio();
			} else if (texto == 1) {
				new Promedio().mostrarPromedio();
			} else if (texto == 2) {
				new CalPromedioPar().mostrarPromedio();
			} else if (texto == 4) {
				new MatrizPrincipal().execute();
			}
			texto = new Principal().leerLinea();
			
		}
		System.out.println("Gracias por participar");
	}

	public int leerLinea() {

		Scanner leer = new Scanner(System.in);
		System.out.println("Escribe que programa quieres usar");
		System.out.println("1. Promedio Numeros Positivos y Negativos");
		System.out.println("2. Promedio Numeros Pares");
		System.out.println("3. Promedio Calificaciones");
		System.out.println("4. Suma Matrices");
		System.out.println("5. Salir");

		int numero = leer.nextInt();
		return numero;
	}
}
