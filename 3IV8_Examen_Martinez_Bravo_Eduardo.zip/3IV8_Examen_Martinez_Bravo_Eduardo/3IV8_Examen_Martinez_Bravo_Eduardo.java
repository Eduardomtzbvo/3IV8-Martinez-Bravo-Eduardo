/*Este programa ayudara a distintas personas
a poder conocer el mundo de pokemon*/
import java.util.*;

public class 3IV8_Examen_Martinez_Bravo_Eduardo{

public static void main(String[] args) {

    System.out.println("Escoge lo que quieras ver")
    System.out.println("1 Charmander")
    System.out.println("Bulbasaur")
    System.out.println("3 Squirtle")
    System.out.println("4 Pelea pokemon")
    System.out.println("Salir")
    Scanner entrada = new Scanner(System.in);

    


    if ()
}
}