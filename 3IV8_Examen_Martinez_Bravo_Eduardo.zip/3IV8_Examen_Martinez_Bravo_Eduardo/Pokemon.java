/*Este programa nos ayudara 
para conocer mas de los pokemones*/

public class Pokemon{

    public Pokemon(int id, String nombre, int fuerza, int defensa, int defensa, int vida, int ataque_principal, int ataque_secundario){
        this id
    }
    
    private int id;
    private String nombre;
    private int fuerza;
    private int defensa;
    private int vida;
    private int ataque_principal;
    private int ataque_secundario;

    
    
}