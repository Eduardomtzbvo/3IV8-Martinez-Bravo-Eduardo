/* Esta clase nos ayudara a conocer
los atributos de los pokemones*/

public class Atributos{

public static void main(String[] args) {
    
    
}
}